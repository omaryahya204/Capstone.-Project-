import {useState} from "react";

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
import { useState } from 'react';

export const useSubmit = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState(null);

  const submit = async (data) => {
    setIsLoading(true);
    try {
      // محاكاة استدعاء API
      const isSuccess = Math.random() > 0.5; // 50% احتمال النجاح
      const message = isSuccess ? 'تم الإرسال بنجاح' : 'حدث خطأ أثناء الإرسال';
      setResponse({ type: isSuccess ? 'success' : 'error', message });
    } catch (error) {
      setResponse({ type: 'error', message: 'حدث خطأ أثناء الاتصال' });
    }
    setIsLoading(false);
  };

  return { submit, isLoading, response };
};
import { useState } from 'react';

export const useSubmit = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState(null);

  const submit = async (data) => {
    setIsLoading(true);
    try {
      // محاكاة استدعاء API
      const isSuccess = Math.random() > 0.5; // 50% احتمال النجاح
      const message = isSuccess ? 'تم الإرسال بنجاح' : 'حدث خطأ أثناء الإرسال';
      setResponse({ type: isSuccess ? 'success' : 'error', message });
    } catch (error) {
      setResponse({ type: 'error', message: 'حدث خطأ أثناء الاتصال' });
    }
    setIsLoading(false);
  };

  return { submit, isLoading, response };
};

const useSubmit = () => {
  const [isLoading, setLoading] = useState(false);
  const [response, setResponse] = useState(null);

  const submit = async (url, data) => {
    const random = Math.random();
    setLoading(true);
    try {
      await wait(2000);
      if (random < 0.5) {
        throw new Error("Something went wrong");
      }
      setResponse({
        type: 'success',
        message: `Thanks for your submission ${data.firstName}, we will get back to you shortly!`,
      })
    } catch (error) {
      setResponse({
        type: 'error',
        message: 'Something went wrong, please try again later!',
      })
    } finally {
      setLoading(false);
    }
  };

  return { isLoading, response, submit };
}

export default useSubmit;

import React from "react";
import { Avatar, Heading, VStack } from "@chakra-ui/react";
import FullScreenSection from "./FullScreenSection";

const greeting = "Hello, I am Pete!";
const bio1 = "A frontend developer";
const bio2 = "specialised in React";
import React from "react";
import { Avatar, Heading, Text, VStack } from "@chakra-ui/react";

const LandingSection = () => {
  // البيانات موجودة فوق الملف في المتغيرات (greeting, bio1, bio2)
  const greeting = "Hi, I'm Ahmed!";
  const bio1 = "A passionate React developer.";
  const bio2 = "I love building modern, responsive web apps.";

  return (
    <VStack
      id="landing-section"
      spacing={6}
      justify="center"
      align="center"
      minH="100vh"
    >
      {/* الصورة الرمزية */}
      <Avatar
        size="2xl"
        name="Ahmed"
        src="https://i.pravatar.cc/150?img=7"
      />

      {/* التحية */}
      <Heading as="h2" size="xl">
        {greeting}
      </Heading>

      {/* الوصف */}
      <Text fontSize="lg">{bio1}</Text>
      <Text fontSize="lg">{bio2}</Text>
    </VStack>
  );
};

export default LandingSection;


const LandingSection = () => (
  <FullScreenSection
    justifyContent="center"
    alignItems="center"
    isDarkBackground
    backgroundColor="#2A4365"
  >

  </FullScreenSection>
);

export default LandingSection;

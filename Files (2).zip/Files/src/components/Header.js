import React from 'react';
import { HStack, Box } from '@chakra-ui/react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faTwitter, faLinkedin } from '@fortawesome/free-brands-svg-icons';
import { handleClick } from './utils'; // افترض أن لديك دالة handleClick مخصصة

const socials = [
  { name: 'Facebook', icon: faFacebook, url: 'https://facebook.com' },
  { name: 'Twitter', icon: faTwitter, url: 'https://twitter.com' },
  { name: 'LinkedIn', icon: faLinkedin, url: 'https://linkedin.com' },
];

const Header = () => {
  return (
    <Box bg="black" color="white" p={4}>
      <HStack spacing={4} align="center">
        {/* روابط الوسائط الاجتماعية */}
        {socials.map((social) => (
          <a href={social.url} key={social.name}>
            <FontAwesomeIcon icon={social.icon} size="2x" />
          </a>
        ))}
        {/* الروابط الداخلية */}
        <a href="#projects-section" onClick={handleClick}>المشاريع</a>
        <a href="#contactme-section" onClick={handleClick}>اتصل بي</a>
      </HStack>
    </Box>
  );
};

export default Header;

import { Heading, HStack, Image, Text, VStack } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  import React from "react";
import {
  Box,
  Image,
  Heading,
  Text,
  Link,
  VStack,
  HStack,
  Button,
  useColorModeValue,
} from "@chakra-ui/react";

const Card = ({ title, description, imageUrl, demoLink, codeLink }) => {
  return (
    <Box
      borderWidth="1px"
      borderRadius="lg"
      overflow="hidden"
      shadow="md"
      bg={useColorModeValue("white", "gray.800")}
      _hover={{ transform: "scale(1.03)", transition: "0.3s" }}
    >
      {/* صورة المشروع */}
      <Image src={imageUrl} alt={title} w="100%" h="200px" objectFit="cover" />

      {/* النصوص والمحتوى */}
      <VStack align="start" spacing={3} p={4}>
        <Heading as="h3" size="md">
          {title}
        </Heading>
        <Text color={useColorModeValue("gray.600", "gray.300")}>
          {description}
        </Text>

        {/* الروابط */}
        <HStack spacing={4}>
          {demoLink && (
            <Button
              as={Link}
              href={demoLink}
              isExternal
              colorScheme="teal"
              size="sm"
            >
              Live Demo
            </Button>
          )}
          {codeLink && (
            <Button
              as={Link}
              href={codeLink}
              isExternal
              colorScheme="gray"
              size="sm"
            >
              View Code
            </Button>
          )}
        </HStack>
      </VStack>
    </Box>
  );
};

  export default Card;
  
  
  return null;
};

export default Card;

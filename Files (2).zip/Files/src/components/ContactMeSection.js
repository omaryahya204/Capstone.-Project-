import React from 'react';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { FormControl, FormLabel, Input, FormErrorMessage, Button, VStack } from '@chakra-ui/react';
import { useSubmit } from './useSubmit'; // افترض أنك تستخدم هذا hook

const validationSchema = Yup.object({
  firstName: Yup.string().required('مطلوب'),
  email: Yup.string().email('عنوان بريد إلكتروني غير صحيح').required('مطلوب'),
  type: Yup.string().nullable(),
  comment: Yup.string().min(25, 'يجب أن يكون 25 حرفًا على الأقل').required('مطلوب'),
});

const ContactMeSection = () => {
  const { submit, isLoading, response } = useSubmit();

  const handleSubmit = (values, { resetForm }) => {
    submit(values)
      .then(() => {
        // إذا كان الاستجابة ناجحة، قم بإعادة تعيين النموذج
        resetForm();
      });
  };

  return (
    <VStack id="contactme-section" p={8}>
      <Formik
        initialValues={{ firstName: '', email: '', type: '', comment: '' }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {formik => (
          <form onSubmit={formik.handleSubmit}>
            <FormControl isInvalid={formik.touched.firstName && formik.errors.firstName}>
              <FormLabel htmlFor="firstName">الاسم</FormLabel>
              <Input {...formik.getFieldProps('firstName')} id="firstName" />
              <FormErrorMessage>{formik.errors.firstName}</FormErrorMessage>
            </FormControl>

            <FormControl isInvalid={formik.touched.email && formik.errors.email}>
              <FormLabel htmlFor="email">البريد الإلكتروني</FormLabel>
              <Input {...formik.getFieldProps('email')} id="email" />
              <FormErrorMessage>{formik.errors.email}</FormErrorMessage>
            </FormControl>

            <FormControl>
              <FormLabel htmlFor="type">نوع الاستفسار</FormLabel>
              <Input {...formik.getFieldProps('type')} id="type" />
            </FormControl>

            <FormControl isInvalid={formik.touched.comment && formik.errors.comment}>
              <FormLabel htmlFor="comment">الرسالة</FormLabel>
              <Input {...formik.getFieldProps('comment')} id="comment" />
              <FormErrorMessage>{formik.errors.comment}</FormErrorMessage>
            </FormControl>

            <Button type="submit" isLoading={isLoading}>إرسال</Button>
          </form>
        )}
      </Formik>
    </VStack>
  );
};

export default ContactMeSection;
